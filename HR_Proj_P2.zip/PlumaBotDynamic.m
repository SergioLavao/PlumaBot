%Dynamic Model
m_1 = 0.01;
m_2 = 0.01;

lc_1 = 0.1;
lc_2 = 0.1;