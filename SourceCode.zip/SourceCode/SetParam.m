[ROBOT, PARAM] = pluma_param();
