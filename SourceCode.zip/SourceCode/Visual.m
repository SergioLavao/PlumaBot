[ROBOT, PARAM] = pluma_param();
ROBOT.plot3d(q, 'path', 'C:\Users\sergi\Desktop\SergioLavao\PlumaBot\Source\Model', 'workspace',[-0.25 0.25 -0.25 0.25 -0.05 0.1]);
ROBOT.T()